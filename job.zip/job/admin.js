


/*function retriveData(){
    var n1=document.getElementById('name1').Value;
    var e1=document.getElementById('Email1').Value;
    var a1=document.getElementById('age1').Value;
    var p1=document.getElementById('phone1').Value;
    var adh1=document.getElementById('adhar1').Value;
    var adr1=document.getElementById('adress1').Value;
    var d1=document.getElementById('date1').Value;
    
    var arr=[n1,e1,a1,p1,adh1,adr1,d1];
    return arr;
}
function getData(){
    var n2=localStorage.getItem("Name",a);
    var e2=localStorage.getItem("Email",b);
    var a2=localStorage.getItem("Age",c);
    var p2=localStorage.getItem("Phone",d);
    var adh2=localStorage.getItem("Adhaar",e);
    var adr2=localStorage.getItem("Address",f);
    var d2=localStorage.getItem("Date",g);
    
    var arr=[n2,e2,a2,p2,,adh2,adr2,d2];
    return arr;
}*/
function getData(gdata){

var n2=localStorage.getItem("Name",setData[0]);
var e2=localStorage.getItem("Email",setData[1]);
var a2=localStorage.getItem("Age",setData[2]);
var p2=localStorage.getItem("Phone",setData[3]);
var adh2=localStorage.getItem("Adhaar",setData[4]);
var adr2=localStorage.getItem("Address",setData[5]);
var d2=localStorage.getItem("Date",setData[6]);

var arr=[n2,e2,a2,p2,,adh2,adr2,d2];
return arr;
}

function insert(gdata){
    var table=document.getElementById("myTable");
    var row= table.insertRow();
    var cell1=row.insertCell(0);
    var cell2=row.insertCell(1);
    var cell3=row.insertCell(2);
    var cell4=row.insertCell(3);
    var cell5=row.insertCell(4);
    var cell6=row.insertCell(5);
    var cell7=row.insertCell(6);

    cell1.innerHTML=gdata[0];
    cell2.innerHTML=gdata[1];
    cell3.innerHTML=gdata[2];
    cell4.innerHTML=gdata[3];
    cell5.innerHTML=gdata[4];
    cell6.innerHTML=gdata[5];
    cell7.innerHTML=gdata[6];

}